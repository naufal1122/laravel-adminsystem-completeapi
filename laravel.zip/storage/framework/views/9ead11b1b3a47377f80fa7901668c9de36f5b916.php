<ul>
    <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('dashboard72')); ?>" class="nav-link">
                <p>
                    Dashboard
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('agama72')); ?>" class="nav-link">
                <p>
                    Crud Agama
                </p>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(url('logout72')); ?>" class="nav-link">
                <p>
                    Logout
                </p>
            </a>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a href="<?php echo e(url('profile72')); ?>" class="nav-link">
                <p>
                    Dashboard
                </p>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(url('/changePassword72')); ?>" class="nav-link">
                <p>
                    Ganti Password
                </p>
            </a>
        </li>


        <li class="nav-item">
            <a href="<?php echo e(url('logout72')); ?>" class="nav-link">
                <p>
                    Logout
                </p>
            </a>
        </li>
    <?php endif; ?>
</ul>
<?php /**PATH D:\backend-uts-main\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>