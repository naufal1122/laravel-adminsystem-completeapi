<div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(URL::to('/photo/'. Auth::user()->foto)); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="info">
          <a>Anda Login sebagai <button type="button" class="btn btn-info btn-sm"> <?php echo e(Auth::user()->role); ?></button></a>
        </div>
        </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>
</div>

    <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('welcome96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                    Dashboard
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('dashboard96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    User Management
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('agama96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-pray"></i>
                <p>
                    CRUD Agama
                </p>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(url('logout96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-sign-out-alt"></i>
                <p>
                    Logout
                </p>
            </a>
        </li>
    <?php else: ?>
        <li class="nav-item">
            <a href="<?php echo e(url('welcome96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-table"></i>
                <p>
                    Dashboard
                </p>
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('profile96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-user"></i>
                <p>
                    Edit Profile
                </p>
            </a>
        </li>

        <li class="nav-item">
            <a href="<?php echo e(url('/changePassword96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-key"></i>
                <p>
                    Ganti Password
                </p>
            </a>
        </li>


        <li class="nav-item">
            <a href="<?php echo e(url('logout96')); ?>" class="nav-link">
                <i class="nav-icon fas fa-sign-out-alt"></i>
                <p>
                    Logout
                </p>
            </a>
        </li>
    <?php endif; ?>
<?php /**PATH E:\Keperluan Study\DATABASE\Xampp\htdocs\Praktik Pemrograman Back End Semester 3\application\laravel-adminsystem\resources\views/include/sidebar.blade.php ENDPATH**/ ?>